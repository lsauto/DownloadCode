Examples of human detection:
----------------------------
(samples are from the ETHZ dataset)
- single file:
detectorPLS.exe -d -c Config.hd.INRIA.64x128.2s.txt -i input/humans/image_00000696_0.png -o ./  -b -s 
(detect humans in input/humans/image_00000696_0.png and write the result to the current dir)


- multiple files in a directory:
detectorPLS.exe -d -c Config.hd.INRIA.64x128.2s.txt -i input/humans -o output/ -b -s
(detect humans from images in input/humans, write result to directory output)


Examples of face detection:
---------------------------
-> 3nd: execute face detection:
detectorPLS.exe -d -c Config.fd.Caltech.32x42.1s  -i input/faces -o output/ -b -s


Note: to see the steps necessary to execute detectorPLS.exe to learn a new model, 
please download DetectorPLS.v.0.1.1_faces.zip.
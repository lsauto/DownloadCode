function [vp, residual] = RefineVPByNewtonIteration(linePlaneNormal, initVP, Classification)
%%%This function is to refine the estimated vanishing points according to the
%%%classification result by newton iteration method
%%% Input: linePlaneNormal -- the normal of the line interpretation plane in camera frame.
%%%        initVP -- initial value of vanishing points
%%%        Classification -- the line classification results
%%% Output: vp -- refined vanishing points
%%%         residual -- the residual

small = 1e-4;
TOL = 1e-3;% tolerance for declaration of convergence
DAMPED = 1; %for the damped method to achieve global convergence
nmax = 5; %maximum number of iteration steps
MaxDampCount = 5;%maximum number of iteration steps of damp process

rho = 0.5; % parameter for damped method
alpha0 =0.6;%parameter for update
initVP = initVP/det(initVP); % convert to a rotation matrix
vp = initVP;

% [phiX, phiY, phiZ]=rot2EulerAngleXYZ(vp);%get the intial value of rotation angle

numOfLines = size(linePlaneNormal,1);
residual = zeros(numOfLines,1);
for lineID=1:numOfLines
    class = Classification(lineID);
    residual(lineID) =  (linePlaneNormal(lineID,:)*vp(:,class))^2;    
end

nit = 0;
zerovec3 = [0,0,0];
while((nit < nmax) && (norm(residual) > TOL))
    nit = nit + 1;
    % get derivative
    [phiX, phiY, phiZ]=rot2EulerAngleXYZ(vp);
    cosX = cos(phiX);     sinX = sin(phiX);
    cosY = cos(phiY);     sinY = sin(phiY);
    cosZ = cos(phiZ);     sinZ = sin(phiZ);
    dVP_phiX = [zerovec3; -vp(3,:); vp(2,:)];
    dVP_phiY = [1,0,0; 0,cosX, -sinX;0,sinX,cosX]*...
               [-sinY, 0, cosY; 0,0,0; -cosY,0,-sinY]*...
               [cosZ, -sinZ,0; sinZ,cosZ,0; 0,0,1];
    dVP_phiZ = [vp(:,2), -vp(:,1), zerovec3'];
    df_phiX = zeros(numOfLines,1); 
    df_phiY = zeros(numOfLines,1); 
    df_phiZ = zeros(numOfLines,1);  
    for lineID=1:numOfLines
        class  = Classification(lineID);
        normal = linePlaneNormal(lineID,:);
        tempVec= normal*vp(:,class)*normal;
        df_phiX(lineID) = tempVec*dVP_phiX(:,class);
        df_phiY(lineID) = tempVec*dVP_phiY(:,class);
        df_phiZ(lineID) = tempVec*dVP_phiZ(:,class);
    end
    dfMat = [df_phiX,df_phiY,df_phiZ];
    % get search direction
    delta = -inv(dfMat'*dfMat)*dfMat'*residual;
    if(norm(delta)<small)% zero derivative -> divergence of the method
        break;
    else
        alpha = alpha0; % damping parameter set to 1
        % update
        newphiX = phiX + alpha*delta(1);
        newphiY = phiY + alpha*delta(2);
        newphiZ = phiZ + alpha*delta(3);
        vp = eulerAngleXYZ2Rot(newphiX, newphiY, newphiZ);
        %compute the new residual
        residual_old_norm = norm(residual);
        for lineID=1:numOfLines
            class = Classification(lineID);
            residual(lineID) = (linePlaneNormal(lineID,:)*vp(:,class))^2;
        end
        if (DAMPED)
            %adjust the damping parameter until find a better solution
            dampCount = 0;
            while (norm(residual) >= residual_old_norm)&&(dampCount<MaxDampCount)
                dampCount = dampCount +1;
                alpha = rho*alpha; % damping parameter is adjusted
                newphiX = phiX + alpha*delta(1);
                newphiY = phiY + alpha*delta(2);
                newphiZ = phiZ + alpha*delta(3);
                vp = eulerAngleXYZ2Rot(newphiX, newphiY, newphiZ);
                for lineID=1:numOfLines
                    class = Classification(lineID);
                    residual(lineID) = (linePlaneNormal(lineID,:)*vp(:,class))^2;
                end
            end
        end
    end
end

return
function [bestClassification, info] = ClassifyFewLines(lines, kMaxNumHyp, kMinNumHyp, kAcceptHypotheseThreshold, kInClassResidualThreshold, kRefineMethod)
%%This function is to classify lines according to their directions in the Manhattan world.
%%Only few lines are extracted from image.
%Input:  lines      --  the extracted lines represented on the Equivalent sphere, line(i,:) = [i, sx, sy,sz, ex, ey, ez ]
%        kMaxNumHyp --  the max number of hypotheses generated in ransac procedure. The
%                       adaptive method (see Hartley and Zisserman, p. 120) for determining number
%                       of hypotheses will stop when reaches this number.
%        kMinNumHyp --  the min number of hypotheses in ransac procedure that will be
%                       generated before adaptive method (see Hartley and Zisserman, p. 120) kicks in.
%        kAcceptHypotheseThreshold -- the threshold to accept a hypothesis. When more than 90% inliers are established
%                                     by a hypothesis, then stop test the other hypotheses.
%        kInClassResidualThreshold -- the threshold to decide whether to accept a line within a class (Xdir, Ydir, Zdir)
%        kRefineMethod  -- the way to refine the estimated vanishing points and classification results: 'Iter' or 'SVD'.
%Output: bestClassification -- A vector with numbers from 0-3, corresponding to each line input in
%                              lines argument. 0 indicates the outliers, and 1-3 denote one of the three
%                              cardinal classed assigned to the line.
%        info --  A data structure containing basic debugging information. The field names
%                 are self explanatory.

timeStart = tic;
% get the number of lines
numOfLines = size(lines,1);

linePlaneNormal = zeros(numOfLines,3);%store interpretation plane normal,linePlaneNormal(i,:)=[nx,ny,nz]
% compute the normal of interpretation plane of each line
for i=1:numOfLines
    normal_c = cross(lines(i,2:4), lines(i,5:7));% the normal of the line interpretation plane in the camera frame.
    normal_c = normal_c/norm(normal_c);
    linePlaneNormal(i,:) = normal_c;
end


%%%The following code is to use RANSAC to find the best set of hypotheses.

% generate unique random hypotheses
kMaxID = numOfLines*(numOfLines-1)*(numOfLines-2)/6 - 1;
%generate more hypotheses to ensure enough unique hypotheses available
randomValues = rand(1,ceil(kMaxNumHyp*1.2));
randomCompositeID = ceil(randomValues*(kMaxID-1e-8));
[~, ~, J] = unique(randomCompositeID);
randomCompositeID = randomCompositeID(unique(J));
% ensure that no more than # of unique lines are requested
kMaxNumHyp = min(length(randomCompositeID),kMaxNumHyp);
randomCompositeID = randomCompositeID(1:kMaxNumHyp);


%Initialize the best results
bestClassification = zeros(numOfLines,1);
bestVPXYZ          = zeros(3,3);
bestHypothesis     = [];
bestNumInliers     = 0;

if bestNumInliers/numOfLines < kAcceptHypotheseThreshold
   bFast = 0;
   %now we employ the adaptive RANSAC method.
   log01 = log(0.01);
   % hypotheses  evaluation loop
   numHyp = kMaxNumHyp;% numHyp will be adaptive adjusted.
   hypCount = 0;
   while  hypCount < numHyp
       hypCount = hypCount + 1;
       % get the sample subset
       hypSelectLines = GetCase(randomCompositeID(hypCount));
       % compute the vanishing points for this subset
       [vanishingPoint, numofResults] = SolveHypVP( lines(hypSelectLines,:), linePlaneNormal(hypSelectLines,:), bFast);
       % count the inliers, if more than previous, update the best hypotheses
       for resulutsID = 1: numofResults
           newClassification = zeros(numOfLines,1);
           vpXYZ = vanishingPoint(:,3*resulutsID-2 : 3*resulutsID);
           for lineID = 1:numOfLines
               res = abs(linePlaneNormal(lineID,:) * vpXYZ);
               minvalue = sum(abs(res)<0.09);
               [minRes, minClass] = min(res);
               % if one of the residuals is less than threshold, classify the line accordingly
               if minRes < kInClassResidualThreshold && minvalue<2
                   newClassification(lineID) = minClass;
               end
           end
           newNumInliers = sum(newClassification ~= 0);
           % if more inliers are detected with this hyp, update the best hyp
           if newNumInliers > bestNumInliers
               bestNumInliers = newNumInliers;
               bestClassification = newClassification;
               bestVPXYZ          = vpXYZ;
               bestHypothesis     = hypSelectLines;
               newNumHyp = ceil(log01/log(1-(newNumInliers/numOfLines)^3)); %adaptive adjustment
               numHyp = max(min(kMaxNumHyp,newNumHyp), kMinNumHyp);
           end
           if bestNumInliers/numOfLines > kAcceptHypotheseThreshold
               break;
           end
       end
       if bestNumInliers/numOfLines > kAcceptHypotheseThreshold
           break;
       end
   end
end


% finally, refinement the best vanishing point estimation and re-classify
%for few lines, only iterative methods is considered.
timeStartRefine = tic;
%Use Newton iteration
[refinedBestVPXYZ, residual] = RefineVPByNewtonIteration(linePlaneNormal(bestClassification ~= 0,:), ...
    bestVPXYZ, bestClassification(bestClassification ~= 0));
timeToRefine = toc(timeStartRefine);

%re-classify.
newClassification = zeros(1,numOfLines);
for lineID = 1:numOfLines
    res = abs(linePlaneNormal(lineID,:) * refinedBestVPXYZ);
    minvalue = sum(abs(res)<0.09);
    [minRes, minClass] = min(res);    
    if minRes < kInClassResidualThreshold && minvalue<2
        newClassification(lineID) = minClass;
    end
end
newNumInliers     = sum(newClassification ~= 0);
isbetter = 0;
isworse  = 0;
if newNumInliers>bestNumInliers%get better results
    bestClassification = newClassification;
    bestNumInliers     = newNumInliers;
    isbetter = 1;
else
    refinedBestVPXYZ   = bestVPXYZ;
    if newNumInliers<bestNumInliers
        isworse = 1;
    end
end

% create the output argument
info.oldBestVp= bestVPXYZ;
info.bestVP   = refinedBestVPXYZ;
info.hypCount = hypCount;
info.bestNumInliersRatio= bestNumInliers/numOfLines;
info.bestHypothesis = bestHypothesis;
info.isbetter = isbetter;
info.isworse  = isworse;
info.timeClassifyLines = toc(timeStart);
info.timeToRefine = timeToRefine;

return
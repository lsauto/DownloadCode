 This document is the matlab implementation of the vanishing point estimation algorithm proposed in our papar:
 Lilian Zhang and Reinhard Koch, Vanishing Points Estimation and Line Classification in a Manhattan World, In Proceedings of ACCV2012, November 2012, Daejeon, Korea.

 You can run mainVanishingPointDetection.m to test the algorithm. 
 Before that, you have to download the YorkUrbanDB from:http://elderlab.yorku.ca/YorkUrbanDB/. 
 You may also modify the path in mainVanishingPointDetection.m to run the algorithm.

 If you want to test your own image, you need to extract lines and store them  into a file (eg., lines.txt) in the following format:
 %lineID  sx         sy         ex         ey  
  1       368.866    346.805    372.633    386.804
  2       613.124    425.886    488.133    425.257
  3       460.559    475.428    520.557    479
 
 The code is test on Linux 2.6.37.6-0.7-desktop x86_64 system with Matlab version 2011b.
 If you have questions about the algorithm, please feel free to contact me: lz@mip.informatik.uni-kiel.de.